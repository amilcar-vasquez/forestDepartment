from faker import Faker

faker = Faker()
