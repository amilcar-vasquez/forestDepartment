from django.apps import AppConfig


class CoreConfig(AppConfig):
    name = "styleguide_example.core"
