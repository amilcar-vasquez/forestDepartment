from django.apps import AppConfig


class BlogExamplesConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "styleguide_example.blog_examples"
